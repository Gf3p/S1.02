class Question{
    String contenu;
    String reponse;
    String qcm;
}