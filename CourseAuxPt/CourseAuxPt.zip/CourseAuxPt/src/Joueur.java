class Joueur{
    String nom;
    int[] position;
    int nbStar;
    int points;
}