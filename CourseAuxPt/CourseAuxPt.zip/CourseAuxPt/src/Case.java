class Case{
    boolean[] directions;
    String contenu;
    boolean accessible;
}